using UnityEngine;

public class PhysicsControl : MonoBehaviour
{
 
    public Rigidbody2D rb;
    [Header("Ground")]
    [SerializeField] private float groundRayDistance;
    [SerializeField] private Transform leftGroundPoint;
    [SerializeField] private Transform rightGroundPoint;
    [SerializeField] private LayerMask whattoDetect;
    public bool grounded;
    private RaycastHit2D hitInfoLeft;
    private RaycastHit2D hitInfoRight;

    [Header("Wall")]
    [SerializeField] private float wallRayDistance;
    [SerializeField] private Transform wallCheckpointUpper;
    [SerializeField] private Transform wallCheckpointLower;
    public bool wallDetected;
    private RaycastHit2D hitInfoWallUpper;
    private RaycastHit2D hitInfoWallLower;


    private bool CheckWall()
    {
        hitInfoWallUpper=Physics2D.Raycast(wallCheckpointUpper.position, transform.right, wallRayDistance, whattoDetect);
        hitInfoWallLower = Physics2D.Raycast(wallCheckpointLower.position, transform.right, wallRayDistance, whattoDetect);
        Debug.DrawRay(wallCheckpointUpper.position, new Vector3(wallRayDistance, 0, 0), Color.red);
        Debug.DrawRay(wallCheckpointLower.position, new Vector3(wallRayDistance, 0, 0), Color.red);
        if (hitInfoWallUpper|| hitInfoWallLower)
        {
            return true;
        }
        return false;
    }

    private bool CheckGround()
    {
        hitInfoLeft= Physics2D.Raycast(leftGroundPoint.position,Vector2.down, groundRayDistance, whattoDetect);
        hitInfoRight = Physics2D.Raycast(rightGroundPoint.position, Vector2.down, groundRayDistance, whattoDetect);

        Debug.DrawRay(leftGroundPoint.position, new Vector3(0, -groundRayDistance, 0), Color.red);
        Debug.DrawRay (rightGroundPoint.position, new Vector3(0,-groundRayDistance, 0), Color.red);
        if (hitInfoLeft || hitInfoRight)
            return true;

        return false;
    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void FixedUpdate()
    {
        grounded = CheckGround();
        wallDetected = CheckWall();
    }
}
